<template>
    <div class="fixed flex flex-col text-center top-28 right-8 z-50">
        <button class="mt-5 flex justify-center align-middle box-border bg-blue-500 hover:bg-blue-600 text-white font-bold py-3.5 lg:py-2.5 lg:px-1 rounded-full shadow-lg"> 
            <HandThumbUpIcon class="sm:h-auto w-6 lg:h-auto lg:w-8"/>
        </button>
        <span class="m-1 font-semibold">5.5 B</span>
        <button class="mt-5 flex justify-center align-middle box-border bg-blue-500 hover:bg-blue-600 text-white font-bold py-3.5 lg:py-2.5 lg:px-1 rounded-full shadow-lg"> 
            <HandThumbDownIcon class="sm:h-auto w-6 lg:h-auto lg:w-8"/>
        </button>
        <span class="m-1 font-semibold">Dislike</span>
        <button class="mt-5 flex justify-center align-middle box-border bg-blue-500 hover:bg-blue-600 text-white font-bold py-3.5 lg:py-2.5 lg:px-1 rounded-full shadow-lg"> 
            <ChatBubbleLeftRightIcon class="sm:h-auto w-6 lg:h-auto lg:w-8"/>
        </button>
        <span class="m-1 font-semibold">550 M</span>
        <button class="mt-5 flex justify-center align-middle box-border bg-blue-500 hover:bg-blue-600 text-white font-bold py-3.5 lg:py-2.5 lg:px-1 rounded-full shadow-lg"> 
            <ShareIcon class="sm:h-auto w-6 lg:h-auto lg:w-8"/>
        </button>
        <span class="m-1 font-semibold">Share</span>
        <button class="mt-5 flex justify-center align-middle box-border bg-blue-500 hover:bg-blue-600 text-white font-bold py-3.5 lg:py-2.5 lg:px-1 rounded-full shadow-lg"> 
            <EllipsisVerticalIcon class="sm:h-auto w-6 lg:h-auto lg:w-8"/>
        </button>

    </div>
</template>
<script setup>
import { ref } from 'vue'
import {
    HandThumbDownIcon,
    HandThumbUpIcon,
    ChartPieIcon,
    ChatBubbleLeftRightIcon,
    ShareIcon,
    EllipsisVerticalIcon,
} from '@heroicons/vue/24/outline'
</script>
