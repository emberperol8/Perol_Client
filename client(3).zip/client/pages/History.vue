<template>
    
        <div>
           <center> <img class=" my-15 h-35 w-35 rounded-full bg-gray-50 inline-block align-middle" src="../images/h.png" alt="" /> </center>
        </div>

        <div class="my-4 m-4 text-center">
            <h1 class="my-4">Keep track of what you watch</h1>
            <p class="my-4">Watch history isn't viewable when signed out. <a href="">Learn more</a></p>

            <form action="">
                <button class="ml-5 bg-slate-400 hover:bg-slate-400 text-black font-bold py-2 px-4 rounded inline-flex items-center">
                <img class="h-5 w-5" src="../images/user_2102647.png" alt="">
                <span class="ml-2">Sign In</span>
               </button>
               
            </form>
        </div>

</template>