<template>
    <center class="my-6"><iframe class="w-full aspect-video" src="https://www.youtube.com/embed/IN0T1kyvGi4" title="dog funny reels video 🤭Tamil funny video status 😊 trending reel video 😊 comedy status 😝" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
    <center class="my-6"><iframe class="w-full aspect-video" src="https://www.youtube.com/embed/eGi7KsBR5B0" title="TIKTOK DANCE MASHUP MARCH 2024 || TIKTOK DANCE TREND 2024" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
    <center class="my-6"><iframe class="w-full aspect-video" src="https://www.youtube.com/embed/0ffLjP8sRoU" title="PILIIN MO ANG PILIPINAS TIKTOK COMPILATION🇵🇭" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
    <center class="my-6"><iframe class="w-full aspect-video" src="https://www.youtube.com/embed/-9Ksoe0CG88" title="Asoka Trend || TikTok Compilation" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
    <center class="my-6"> <iframe class="w-full aspect-video" src="https://www.youtube.com/embed/MdLabEoOC4Q" title="😂🤣Funny🤣🤣Like and Subscribe 🤣 #best #reels #shorts #funny #dog #dance #epic #fail RB Memes Edit" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
    <center class="my-6"><iframe class="w-full aspect-video" src="https://www.youtube.com/embed/zlKMfqlD84I" title="Kwai Funny tiktok : Funny Videos 2020, Chinese Funny Video - Most View Chinese Funny Video" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
    <center class="my-6"><iframe class="w-full aspect-video" src="https://www.youtube.com/embed/3il9a2Zm34s" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
    <Navigation/>
</template>
        
        
       
        
       
        
