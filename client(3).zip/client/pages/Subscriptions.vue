<template>
   
        <div>
        <center><img class=" my-15 h-35 w-35 rounded-full bg-gray-50 inline-block align-middle" src="../images/s.png" alt="" /></center>
      </div>
       
        
        <div class="my-6 text-center">
           <h1 class="my-4">Don’t miss new videos</h1>
            <p class="my-4">Sign in to see updates from your favorite YouTube channels</p>
            
            <form action="#">
               <button class="ml-5 bg-slate-400 hover:bg-slate-400 text-black font-bold py-2 px-4 rounded inline-flex items-center">
                <img class="h-5 w-5" src="../images/user_2102647.png" alt="">
                <span class="ml-2">Sign In</span>
               </button>
               
                
            </form>
        </div>

</template>